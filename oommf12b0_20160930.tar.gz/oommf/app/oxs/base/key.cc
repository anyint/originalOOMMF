/* FILE: key.cc                 -*-Mode: c++-*-
 *
 * Oxs_Key class, intended for use with the Oxs_Lock family.
 * This is an empty, unused file, but exists to make some
 * pre-linkers happy.  The definitions for this templated
 * class are all in the header file key.h.  See that file
 * for a discussion on the reasons for putting all template
 * definitions in the header file.
 */
